
-- Called by the user input script to make a sketch of the geometric elements.


sk = Sketch:new{renderer="svg", projection="xyortho"}
sk:set{canvas={0.0,0.0,150.0,160.0}, viewport={-0.3,-0.5,1.2,0.5}}
sk:start{file_name="Assignment2.svg"}

-- surfaces
sk:set{line_width=0.5, fill_colour="green"}



sk:dotlabel{point=B0, label="B0"}
sk:dotlabel{point=B1, label="B1"}
sk:dotlabel{point=B2, label="B2"}
sk:dotlabel{point=B3, label="B3"}
sk:dotlabel{point=B4, label="B4"}

sk:render{path=a1a0_new}
sk:render{path=a2a1_new}
sk:render{path=a3a2_new}
sk:render{path=a4a3_new}
-------------------------------------------------
sk:render{path=b1a1}
sk:render{path=b2a2}
sk:render{path=b2b1_new}
-------------------------------------------------
sk:render{path=b1b0}
sk:render{path=b0a0}
-------------------------------------------------
sk:render{path=b3a3}
sk:render{path=b4a4}
sk:render{path=b4b3}
-------------------------------------------------
sk:render{path=b3b2_new}




-- axes
sk:set{line_width=0.3} -- for drawing rules
sk:rule{direction="x", vmin=-0.3, vmax=1.2, vtic=0.2,
       anchor_point=Vector3:new{x=0,y=0},
       tic_mark_size=0.02, number_format="%.1f",
       text_offset=0.06, font_size=10}
sk:text{point=Vector3:new{x=1.4,y=-0.1}, text="x", font_size=12}

sk:rule{direction="y", vmin=-0.3, vmax=0.3, vtic=0.2,
       anchor_point=Vector3:new{x=0,y=0},
       tic_mark_size=0.02, number_format="%.1f",
       text_offset=0.025, font_size=10}
sk:text{point=Vector3:new{x=-0.1,y=0.4}, text="y", font_size=12}

sk:finish{}
