#!/bin/bash





#e4shared --custom-post --script-file="Assignment2.lua"
foamMesh --job=Assignment2 --verbosity=2


