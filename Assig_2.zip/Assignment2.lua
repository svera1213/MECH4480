--
-- Authors:  Team LL
-- Date: 21/08/2018



--*************************** README************************
-- TO RUN THIS CODE 
--1) Navegate to working directory (whereever this files are saved)
--2) $of50
--3) $ . run_Assignment_2.sh  (Make sure foamMesh --job=Assignment2 --verbosity=2 its uncommented)
--4) $ paraFoam

-- To plot paths in .svg
--1) Comment foamMesh --job=Assignment2 --verbosity=2 in run_Assignment2.sh
--2) Uncomment e4shared --custom-post --script-file="Assignment2.lua" in in run_Assignment2.sh
--3) Uncoment last line in this code { dofile("sketch-Assignment2.lua") }
--4) Comment everything from Define patch to the end
--The plot will be saved in the same directory





--################################################################################
--FUNCTIONS
-------------------------------
--Returns length of a table 
function len(table_s)
 local counter = 0
 for index in pairs(table_s) do
  counter = counter +1
 end
 return counter
end
-------------------------------

--################################################################################


--NACA4412 points generator-------------------------------------------------------------------------------
--Uses the standard equations for NACA airfoils
--x-axis points of camber--------------------------------------------------------------

naca_pi_points = {} --list of 100 points from 0 to pi
beta=0

for ib= 0, 99 do
 naca_pi_points[ib] = beta
 beta = beta + math.pi/100
end 

naca_xc_point = {} -- list of 100 points of the camber x coordinates
x = 0

for ib=0, 99 do
 x = (1-math.cos(naca_pi_points[ib]))/2
 naca_xc_point[ib]=x
end

---------------------------------------------------------------------------------
M = 4/100
P = 4/10
XX = 12/100
AoA = 0 --Angle of attack in DEGREES

AoA = AoA*math.pi/180 --Convert to RADIANS
X_centre = 0.25 --Point of rotation from which AoA willchange
 
yc = {}
grad_yc = {}
angle_theta = {}

for ib=0, 99 do
 if naca_xc_point[ib]<P then
  yc[ib]=(M/math.pow(P,2))*(2*P*naca_xc_point[ib]-math.pow(naca_xc_point[ib],2))
  grad_yc[ib]= (2*M/math.pow(P,2))*(P-naca_xc_point[ib])

  dx=(X_centre-naca_xc_point[ib])*( math.tan(AoA) / ( math.tan(AoA)+math.tan((math.pi/2)-(AoA/2)) ) )
  dy=dx*math.tan((math.pi/2)-(AoA/2))
  naca_xc_point[ib]=naca_xc_point[ib]+dx
  yc[ib]=(yc[ib]+dy)

 elseif naca_xc_point[ib]>=P then
  yc[ib]=(M/math.pow ((1-P),2))*(1-2*P+2*P*naca_xc_point[ib]-math.pow (naca_xc_point[ib],2))
  grad_yc[ib]= (2*M/math.pow((1-P),2))*(P-naca_xc_point[ib])

  dx=(X_centre-naca_xc_point[ib])*( math.tan(AoA) / ( math.tan(AoA)+math.tan((math.pi/2)-(AoA/2)) ) )
  dy=dx*math.tan((math.pi/2)-(AoA/2))
  naca_xc_point[ib]=naca_xc_point[ib]+dx
  yc[ib]=(yc[ib]+dy)
    
 else
  error("invalid operation")
 end
 angle_theta[ib] = math.atan(grad_yc[ib])
end

--Thickness----------------------------------------------------------------------
yt = {}

a0=0.2969
a1=-0.126
a2=-0.3516
a3=0.2843
a4=-0.1036

for ib=0, 99 do
 yt[ib]= (XX/0.2)*(a0*math.pow(naca_xc_point[ib],0.5) + a1*naca_xc_point[ib] + a2*math.pow(naca_xc_point[ib],2) + 			a3*math.pow(naca_xc_point[ib],3) + a4*math.pow(naca_xc_point[ib],4))
end 

--Top airfoil--------------------------------------------------------------------
naca_xu = {}
naca_yu = {}

for ib=0, 99 do
 naca_xu[ib] = naca_xc_point[ib] - yt[ib]* math.sin(angle_theta[ib])
 naca_yu[ib] = yc[ib] + yt[ib]* math.cos(angle_theta[ib])
end

--Bottom airfoil-----------------------------------------------------------------
naca_xl = {}
naca_yl = {}

for ib=0, 99 do
 naca_xl[ib] = naca_xc_point[ib] + yt[ib]* math.sin(angle_theta[ib])
 naca_yl[ib] = yc[ib] - yt[ib]* math.cos(angle_theta[ib])
end

--END of NACA4412 points generator-------------------------------------------------------------------------------
--#################################################################################
--DEFINE NACA vertices


--Top Airfoil divided in two parts to form two blocks. One close to leading edge. 
top_front ={} 
top_back = {}

--Uncomment print statements to see vertex location--------------------------------
--print("ib	","X     	","Y	      ","point")
for ib= 0, 99 do

 if naca_xu[ib] < 0.3 and naca_xu[ib] >= 0 then --CHANGE THE 0.3 WITH ANY NUMBER FROM 0.O TO 1.0 

  table.insert(top_front,Vector3:new{x=naca_xu[ib], y=naca_yu[ib]})
  --print(ib,naca_xu[ib],naca_yu[ib],"front = ", top_front[ib])
 elseif naca_xu[ib] >= 0.3 then

  table.insert(top_back,Vector3:new{x=naca_xu[ib], y=naca_yu[ib]})
  --print(ib,naca_xu[ib],naca_yu[ib],"back = ", top_back[ib])
 end


end




table.insert(top_front,top_back[1]) --THIS JOINS THE END OF top_front WITH THE START OF top_back *they share the same 						node*
------------------------------------------------------------------------------------------------------------------

--Bottom Airfoil divided in two parts to form two blocks. One close to leading edge-------------------------------
bottom_front ={}
bottom_back ={}
b_f={} --List created to have the nodes from leading edge till point 0.3. They will be copied to bottom_back in 		opposite order
--------------------------------------------------------------------------



table.insert(b_f,top_front[1]) -- Start of b_f to share the same node as top_front (leading edge node)

for ib= 1, 98 do

 if naca_xl[ib] < 0.3 then --CHANGE THE 0.3 WITH ANY NUMBER FROM 0.O TO 1.0 *same as Top Airfoil
  
  table.insert(b_f,Vector3:new{x=naca_xl[ib], y=naca_yl[ib]})
 elseif naca_xl[ib] >= 0.3 then
  
  table.insert(bottom_back,Vector3:new{x=naca_xl[ib], y=naca_yl[ib]})
 end


end


table.insert(b_f,bottom_back[1]) -- End of b_f and bottom_back share the same node

table.insert(bottom_back,top_back[len(top_back)]) -- end of bottom-back to share the same node as the end of top_back 								(trailing edge node)


--------------------------------------------------------------------------------
--Reverse content in b_f into bottom_front
N= len(b_f)
for ib=0, N do 
 
  table.insert(bottom_front,b_f[N-ib])
end

---------------------------------------------------------------------------------
--#############################################################################


--DEFINE NACA Airfoil paths

--Top Front----------------------------------
top_front_line = Spline:new{points=top_front}

--Top Back 
top_back_line = Spline:new{points=top_back}

--Bottom Front--------------------------------------
bottom_front_line = Spline:new{points=bottom_front}

--Bottom Back
bottom_back_line = ReversedPath:new{underlying_path = Spline:new{points=bottom_back}}
--------------------------------------------------


-- ############################################################
-- DEFINE OUTER NODES. These will be used to form the outer path of the blocks.

-- I'm following the Airfoil2D tutorial

--Outside Vertices-------------------------------------------------------------
BL = 0.2 --DISTANCE FROM THE NODE IN AIRFOIL PROFILE

topBackN = len(top_back) --index of end node from top_back table (trailing edge)

B0 = Vector3:new{x = top_back[topBackN].x, y = top_back[topBackN].y+BL} --trailing edge top
B4 = Vector3:new{x = top_back[topBackN].x, y = top_back[topBackN].y-BL} --trailing edge bottom

B2 = Vector3:new{x = top_front[1].x - BL, y = top_front[1].y} -- leading edge

--calculating gradients/ angles for <mid points>

topFrontN = len(top_front) --index of end node from top_front table
bottomFrontN = 1 --index of start node from bottom_front table (leading edge)

--These formulas are the Airfoil profile gradient equation
grad_A1 = 0.14845*math.pow(top_front[topFrontN].x,-0.5)-0.126-0.7032*top_front[topFrontN].x+0.8529*math.pow(top_front[topFrontN].x,2)-0.4144*math.pow(top_front[topFrontN].x,3)

grad_A3 = 0.14845*math.pow(bottom_front[bottomFrontN].x,-0.5)-0.126-0.7032*bottom_front[bottomFrontN].x+0.8529*math.pow(bottom_front[bottomFrontN].x,2)-0.4144*math.pow(bottom_front[bottomFrontN].x,3)

-- Gradient to angle
alpha_A1 = math.atan(grad_A1)-- I didn't use this but for some reason creates the correct shape *check*
alpha_A3 = math.atan(grad_A3)

-- mid top node
B1 = Vector3:new{x = top_front[topFrontN].x-BL*math.sin(grad_A1), y = top_front[topFrontN].y+BL*math.cos(grad_A1)}

--mid bottom node
B3 = Vector3:new{x = bottom_front[bottomFrontN].x-BL*math.sin(grad_A3), y = bottom_front[bottomFrontN].y-BL*math.cos(grad_A3)}


--------------------------------------------------------------------------------------------------------
--Define midpoints of bezier curves
dx=-(B2.x-B1.x)/2
dy=B1.y/2

B2z1 = Vector3:new{x = B1.x - dx - 0.15, y= B2.y + dy + 0.1}

B2z3 = Vector3:new{x = B3.x - dx - 0.15, y= B2.y - dy - 0.1}

dx1=-(B1.x-B0.x)/2
dy1=0.01

B1z0 = Vector3:new{x = B1.x + dx1, y= B1.y + dy1}

B3z4 = Vector3:new{x = B3.x + dx1, y= B3.y + dy1}

--#######################################################################################################
--DEFINE Paths for each block 

b2b1 = Bezier:new{points={B2, B2z1, B1}}
b3b2 = Bezier:new{points={B3, B2z3, B2}}

b1b0 = Bezier:new{points={B1, B1z0, B0}}
b4b3 = Bezier:new{points={B4, B3z4, B3}}


--Block B0
b1a1 = Line:new{p0=B1 , p1=top_front[topFrontN]} --north
b2a2 = Line:new{p0=B2 , p1=top_front[1]} --south
b2b1_new = ArcLengthParameterizedPath:new{underlying_path= b2b1} --west
a2a1_new = ArcLengthParameterizedPath:new{underlying_path= top_front_line} --east

--Block B1*
b0a0 = Line:new{p0=B0 , p1=top_back[topBackN]} --north
--b1a1 *already created in B0* --south
--b1b0 *already created*	 --west
a1a0_new = ArcLengthParameterizedPath:new{underlying_path= top_back_line} --east


--Block B2
b3a3 = Line:new{p0=B3 , p1=bottom_front[1]} --north
b4a4 = Line:new{p0=B4 , p1=top_back[topBackN]} --south
--b4b3 *already created* --west
a4a3_new = ArcLengthParameterizedPath:new{underlying_path= bottom_back_line} --east

--Block B3
--b2a2 *already created in B0* --north
--b3a3 *already created in B2* --south
b3b2_new = ArcLengthParameterizedPath:new{underlying_path= b3b2} --west
a3a2_new = ArcLengthParameterizedPath:new{underlying_path= bottom_front_line} --east



-- ############################################################
--DEFINE Patches for each block
patch={}

patch[0]= CoonsPatch:new{north=b1a1 ,south=b2a2 ,west=b2b1_new ,east=a2a1_new}
patch[1]= CoonsPatch:new{north=b0a0 ,south=b1a1 ,west=b1b0 ,east=a1a0_new}
patch[2]= CoonsPatch:new{north=b3a3 ,south=b4a4 ,west=b4b3 ,east=a4a3_new}
patch[3]= CoonsPatch:new{north=b2a2 ,south=b3a3 ,west=b3b2_new ,east=a3a2_new}

--CLUSTERING
rcfL = RobertsFunction:new{end0 = false, end1 = true, beta=1.02}


grid = {}
ny=10
grid[0] = StructuredGrid:new{psurface= patch[0], niv=10+1, njv=ny+1, cfList ={north=rcfL, south=rcfL}}
grid[1] = StructuredGrid:new{psurface= patch[1], niv=10+1, njv=ny+1, cfList ={noth=rcfL, south=rcfL}}
grid[2] = StructuredGrid:new{psurface= patch[2], niv=10+1, njv=ny+1, cfList ={north=rcfL, south=rcfL}}
grid[3] = StructuredGrid:new{psurface= patch[3], niv=10+1, njv=ny+1, cfList ={north=rcfL, south=rcfL}}



--####################################################################################################
-- DEFINE each block
blk = {}
	
blk[0] = FoamBlock:new{grid=grid[0], bndry_labels={west="i-00", east="w-01"}}

blk[1] = FoamBlock:new{grid=grid[1], bndry_labels={north="o-00",west="w-00", east="w-01"}}

blk[2] = FoamBlock:new{grid=grid[2], bndry_labels={west="w-00", south="o-00", east="w-01"}}

blk[3] = FoamBlock:new{grid=grid[3], bndry_labels={west="i-00", east="w-01"}}


--END OF CODE


--foamMesh --job=Assignment2 --verbosity=2
--dofile("sketch-Assignment2.lua")
